<?php
// Inclusion de la classe post
require_once "post.class.php";

class postTable {

}

?>
