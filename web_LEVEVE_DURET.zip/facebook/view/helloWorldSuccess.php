
Ceci est un super <?php echo $context->mavariable ?> ! dingue non ? 
