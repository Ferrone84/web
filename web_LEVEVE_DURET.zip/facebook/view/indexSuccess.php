Bienvenue dans l'index ! <a href="facebook.php">Page par défaut</a> <br>
<span id="logout"><a href="facebook.php?action=logout">Deconnectez vous !</a></span>